//
//  RecipeInteractorJSONTest.swift
//  RecipePuppyTests
//
//  Created by Scott Stahurski on 8/29/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import XCTest
@testable import RecipePuppy

class RecipeInteractorJSONTest: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    //test generic data loading of recipes
    func testGenericLoad() throws {

        //create testing Interactor
        let ri:RecipeInteractor = RecipeInteractor()

        //load test data
        ri.loadTestData()
        
        XCTAssert( ri.recipes.count == 3 )
        
        //clear items
        ri.clearRecipes()
        
        XCTAssert( ri.recipes.count == 0 )
    }
    

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
