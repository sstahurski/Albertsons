//
//  ReciepeWebViewController.swift
//  RecipePuppy
//
//  Created by Scott Stahurski on 8/29/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import UIKit
import WebKit

class ReciepeWebViewController: UIViewController {

    var recipeUrl:String!
    
    @IBOutlet var recipeWebView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let url = URL(string: recipeUrl)!
        recipeWebView.load(URLRequest(url: url))
        recipeWebView.allowsBackForwardNavigationGestures = true
    }
    
    func setUrl( urlEndpoint:String ){
        self.recipeUrl = urlEndpoint
    }

}
