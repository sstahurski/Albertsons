//
//  RecipeCollectionViewCell.swift
//  RecipePuppy
//
//  Created by Scott Stahurski on 8/30/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import UIKit

class RecipeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var recipeImageView: UIImageView!
    @IBOutlet var recipeTitleLabel: UILabel!
    @IBOutlet var recipeIngredientsLabel: UILabel!
    
    @IBOutlet var shopRecipeButton: UIButton!
    
    var href:String!

}


