//
//  RecipeSearchViewController.swift
//  RecipePuppy
//
//  Created by Scott Stahurski on 8/29/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import UIKit

protocol RecipeViewProtocol {
    func recipeDataChange()
}


class RecipeSearchViewController: UIViewController, RecipeViewProtocol
{
    @IBOutlet var recipeCollectionView: UICollectionView!
    @IBOutlet var searchTextField: UITextField!
    
    var cachedCellThumbnailImages:[UIImage] = []
    
    //handle to the Viper presenter
    var recipePresenter:RecipePresenter?
    
    
    //MARK: Overrides
    override func viewDidLoad() {
        super.viewDidLoad()
        
        recipePresenter = RecipePresenter(self)
        
    }
    
    
    //MARK: - Selectors
    @IBAction func searchSelector(_ sender: Any) {
        
        //resign first responder
        self.searchTextField.resignFirstResponder()
        
        //scroll to first item
        self.recipeCollectionView?.scrollToItem(at: IndexPath(row: 0, section: 0),
              at: .left,
        animated: true)
        
        //verify we are online
        if( !checkOnlineStatus())
        {
            recipePresenter?.requestOnlineError()            
            return
        }
        
        //defer to presenter
        recipePresenter?.searchForRecipe( searchTextField.text ?? "" )
    }
    
    
    @IBAction func shopRecipeSelector(_ sender: Any) {
        //sender was the button from the collection view cell
        let button = sender as! UIButton
        let index = button.tag
        
        //get the recipe for the index
        let recipe = self.recipePresenter?.getRecipe(index)
        
        //send it on to the presenter
        recipePresenter?.loadRecipeDetailView( recipeUrl: recipe!.href )
    }
    
    //MARK: Presenter actions
    //Data Change from Presenter
    func recipeDataChange() {
        
        //updates to UI on main thread
        DispatchQueue.main.async {
            let recipeCount = self.recipePresenter?.getRecipeCount() ?? 0
            //dump the cached images
            self.cachedCellThumbnailImages.removeAll()
            
            //load up cached images
            for index in 0..<recipeCount {
                //default image
                let cellImage = UIImage(named: "RecipeIcon")
                //get the recipe
                let recipe = self.recipePresenter?.getRecipe(index)
                
                //set default
                self.cachedCellThumbnailImages.append(cellImage!)
                
                //does it have a thumbnail?
                if(recipe?.thumbnail.count ?? 0 > 0){
                    //add the image as default
                    self.searchRecipeImage(query: recipe!.thumbnail, cacheIndex: index)
                }
            }
        
            //now reload the collection view
            self.recipeCollectionView.reloadData()
        }
        
    }
    
    //MARK: Helper methods
    //ask for a thumbnail image from the server
    //this is an active load of the collection view cell
    func searchRecipeImage( query:String, cacheIndex:Int ){
        
        let url = URL(string: query)
        
        //make the call to retrieve the image
        let task = URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, error) in
            
            if error == nil {
                let response = response as? HTTPURLResponse
                if response?.statusCode == 200 {
                    
                    let retrievedImage = UIImage(data: data!)
                    self.cachedCellThumbnailImages[cacheIndex] = retrievedImage!
                    
                    //update
                    let indexPath = IndexPath(row: cacheIndex, section: 0)
                     DispatchQueue.main.async {
                        let cell = self.recipeCollectionView.cellForItem(at: indexPath)
                     
                         if cell != nil && self.recipeCollectionView.visibleCells.contains(cell!) {
                             //update the image view
                             let recipeCell:RecipeCollectionViewCell = cell as! RecipeCollectionViewCell
                             recipeCell.recipeImageView.image = retrievedImage
                         }
                     }
                }
            }
            
        })
        
        task.resume()
    }
    
    func checkOnlineStatus() -> Bool{
        return Connection.isOnline()
    }
}

//MARK: UICollectionViewDataSource
extension RecipeSearchViewController: UICollectionViewDataSource
{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return recipePresenter?.getRecipeCount() ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RecipeCollectionViewCell", for: indexPath) as! RecipeCollectionViewCell

        //get recipe for this row
        let recipe = recipePresenter?.getRecipe(indexPath.row)
        
        //load up the custom cell
        cell.recipeTitleLabel.text          = recipe?.title
        cell.recipeIngredientsLabel.text    = recipe?.ingredients
        cell.href = recipe?.href
        //hide the button if no link
        if (recipe?.href.count == 0 ){
            cell.shopRecipeButton.alpha = 0
        }
        
        //load the image from the cache
        cell.recipeImageView.image = cachedCellThumbnailImages[indexPath.row]
        //set the buttons tag to the index
        cell.shopRecipeButton.tag = indexPath.row
            
        return cell
    }
    
}



