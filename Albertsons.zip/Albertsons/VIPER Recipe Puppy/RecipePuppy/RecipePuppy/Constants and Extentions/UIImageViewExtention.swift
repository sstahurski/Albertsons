//
//  UIImageViewExtention.swift
//  RecipePuppy
//
//  Created by Scott Stahurski on 8/29/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import Foundation
import UIKit

extension UIImageView {
    
    func loadImageFromURL(_ urlString:String ){
        
        //create a non blocking load of the image
        if let url = URL(string:urlString) {
            let task = URLSession.shared.dataTask(with: url, completionHandler: { data, response, error in
                if let data = data {
                    //have to load on main thread
                    DispatchQueue.main.async {
                        self.image = UIImage(data: data)
                    }
                }
            })
            task.resume()
        }
        
    }
}
    

