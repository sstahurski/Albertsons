//
//  RecipePresenter.swift
//  RecipePuppy
//
//  Created by Scott Stahurski on 8/29/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import Foundation

class RecipePresenter {
    
    var recipeInteractor:RecipeInteractor?
    var recipeView:RecipeViewProtocol?
    var recipeRouter:RecipeRouter!
    
    
    init(_ recipeViewProtocol:RecipeViewProtocol){
        //connect to view
        recipeView = recipeViewProtocol
        //create the Interactor
        recipeInteractor = RecipeInteractor(self)
        //create the Router
        recipeRouter = RecipeRouter()
        
    }
    
    init(){
    }
    
    func notifyDataChange(){
        recipeView?.recipeDataChange()
    }
    
    func searchForRecipe(_ searchValue:String){
        recipeInteractor?.queryRecipes(searchValue)
    }
    
    func getRecipeCount()->Int{
        return recipeInteractor?.getRecipeCount() ?? 0
    }
    
    func getRecipe(_ index:Int)->RecipeEntity?{
        return recipeInteractor?.getRecipe(index: index) ?? nil
    }
    
    func loadRecipeDetailView( recipeUrl:String){
        recipeRouter.loadRecipeDetailView(url: recipeUrl)
    }
    
    func requestOnlineError() {
        recipeRouter.loadOnlineError()
    }
    
}
