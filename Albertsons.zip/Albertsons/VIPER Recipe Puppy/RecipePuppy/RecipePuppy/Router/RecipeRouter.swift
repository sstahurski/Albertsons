//
//  RecipeRouter.swift
//  RecipePuppy
//
//  Created by Scott Stahurski on 8/29/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import Foundation
import UIKit

class RecipeRouter {
    
    func loadRecipeDetailView( url:String ){
        //load up the RecipeWebViewController
        if let navigationController = UIApplication.shared.windows.filter({$0.isKeyWindow}).first?.rootViewController as? UINavigationController {
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyBoard.instantiateViewController(withIdentifier:"ReciepeWebViewController") as! ReciepeWebViewController
            viewController.setUrl(urlEndpoint: url)
            
            navigationController.pushViewController(viewController, animated: true)
        }
    }
    
    func loadOnlineError(){
        //load up the RecipeWebViewController
        if let navigationController = UIApplication.shared.windows.filter({$0.isKeyWindow}).first?.rootViewController as? UINavigationController {

            //create alert
            let alertController = UIAlertController(title: "Please Connect...", message: "You must be connected to the internet in order search for recipes", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
            //show alert
            navigationController.present(alertController, animated: true, completion:nil )
            
        }
        
    }
    
    
}
