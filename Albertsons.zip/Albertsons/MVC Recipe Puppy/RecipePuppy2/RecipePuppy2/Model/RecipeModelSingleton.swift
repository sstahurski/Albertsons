//
//  RecipeModelSingleton.swift
//  RecipePuppy2
//
//  Created by Scott Stahurski on 8/30/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import UIKit

class RecipeModelSingleton {
    
    //Singleton Instance
    static let instance = RecipeModelSingleton()
    
    //Our list of queried Recipes
    var recipes:[Recipe] = []

    //initialize
    func initialize() {
    }
    
    //get count
    func getRecipeCount()->Int{
        return recipes.count
    }

    //get recipe
    func getRecipe(index:Int)->Recipe?{
        
        if( index < recipes.count)
        {
            return recipes[index]
        }
        
        return nil
    }
    
    //clear the recipe list
    func clearRecipes() {
        self.recipes.removeAll();
    }
    
    
    //query recipe
     func queryRecipes(_ searchValue:String, completionHandler: @escaping () -> Void ){
         //remove all exiting recipes from out list
         self.clearRecipes()
         
         //use the query string to get a new array from service
         var urlString:String  = PUPPY_RECIPE_QUERY_URL + searchValue
         //replace all spaces with '+'
         urlString = urlString.replacingOccurrences(of: " ", with: "+")
         print("url query is \(urlString)")
         //create the URL
         let url = URL(string: urlString)
         
         //make the call to get the first page of recipes
         let task = URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, error) in
             if error == nil {
                 do{
                     let jsonDecoder = JSONDecoder()
                     let rawData = try jsonDecoder.decode(RecipePage.self, from: data!)
                     
                     //add recipe to our search
                     for recipeData in rawData.results{
                         self.recipes.append(recipeData)
                     }
                    
                    //Run the closure...we are done
                    completionHandler()
                 }
                 catch {
                     print("Data could not load from file:\(error)")
                 }
             }
         })
         
         //start the task
         task.resume()
     }


}
