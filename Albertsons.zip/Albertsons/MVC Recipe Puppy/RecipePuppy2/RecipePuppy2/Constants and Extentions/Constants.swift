//
//  Constants.swift
//  RecipePuppy2
//
//  Created by Scott Stahurski on 8/30/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import Foundation

let PUPPY_RECIPE_QUERY_URL:String = "http://www.recipepuppy.com/api/?q="
