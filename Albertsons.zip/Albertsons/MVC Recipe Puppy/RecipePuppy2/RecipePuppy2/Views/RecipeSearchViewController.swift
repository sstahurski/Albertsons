//
//  RecipeSearchViewController.swift
//  RecipePuppy2
//
//  Created by Scott Stahurski on 8/30/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import UIKit

class RecipeSearchViewController: UIViewController {

    
    @IBOutlet var recipeCollectionView: UICollectionView!
    @IBOutlet var searchTextField: UITextField!
    
    var cachedCellThumbnailImages:[UIImage] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //MARK: - Selectors
    @IBAction func searchSelector(_ sender: Any)
    {
        //resign first responder
        self.searchTextField.resignFirstResponder()
        
        //verify we are online
        if( !checkOnlineStatus())
        {
            let alertController = UIAlertController(title: "Please Connect...", message: "You must be connected to the internet in order search for recipes", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler:nil))
            //show alert
            self.present(alertController, animated: true, completion:nil )
            
            return
        }
        
        //create a closure to run after the search
        let searchCompletionHandler: () -> Void = {
            
            let recipeCount = RecipeModelSingleton.instance.getRecipeCount()
            //dump the cached images
            self.cachedCellThumbnailImages.removeAll()
            
            //load up cached images
            for index in 0..<recipeCount {
                //default image
                let cellImage = UIImage(named: "RecipeIcon")
                //get the recipe
                let recipe = RecipeModelSingleton.instance.getRecipe(index: index)
                
                //set default
                self.cachedCellThumbnailImages.append(cellImage!)
                
                //does it have a thumbnail?
                if(recipe?.thumbnail.count ?? 0 > 0){
                    //add the image as default
                    self.searchRecipeImage(query: recipe!.thumbnail, cacheIndex: index)
                }
            }
            
            
            DispatchQueue.main.async {
                self.recipeCollectionView.reloadData()
                //scroll to first item
                self.recipeCollectionView?.scrollToItem(at: IndexPath(row: 0, section: 0), at: .left, animated: false)
            }
        }
        
        //do a search
        RecipeModelSingleton.instance.queryRecipes( searchTextField.text!, completionHandler:searchCompletionHandler)
        
    }
    
    //MARK: Helper methods
    //ask for a thumbnail image from the server
    //this is an active load of the collection view cell
    func searchRecipeImage( query:String, cacheIndex:Int ){
        
        let url = URL(string: query)
        
        //make the call to retrieve the image
        let task = URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, error) in
            
            if error == nil {
                let response = response as? HTTPURLResponse
                if response?.statusCode == 200 {
                    
                    let retrievedImage = UIImage(data: data!)
                    self.cachedCellThumbnailImages[cacheIndex] = retrievedImage!
                    
                    //update
                    let indexPath = IndexPath(row: cacheIndex, section: 0)
                     DispatchQueue.main.async {
                        let cell = self.recipeCollectionView.cellForItem(at: indexPath)
                     
                         if cell != nil && self.recipeCollectionView.visibleCells.contains(cell!) {
                             //update the image view
                             let recipeCell:RecipeCollectionViewCell = cell as! RecipeCollectionViewCell
                             recipeCell.recipeImageView.image = retrievedImage
                         }
                     }
                }
            }
            
        })
        
        task.resume()
    }
    
    @IBAction func shopRecipeSelector(_ sender: Any) {
        
        //sender was the button from the collection view cell
        let button = sender as! UIButton
        let index = button.tag
        
        //get the recipe for the index
        let recipe = RecipeModelSingleton.instance.getRecipe(index: index)
        
        //send it on to seque
        self.performSegue(withIdentifier: "ShowWebViewSeque", sender: recipe)

    }
    
    
    //MARK: - Helper Functions
    func checkOnlineStatus() -> Bool{
        return Connection.isOnline()
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ShowWebViewSeque" && sender != nil {
            let recipe:Recipe = sender as! Recipe
            
            let recipeWebViewController:RecipeWebViewController = segue.destination as! RecipeWebViewController
            
            recipeWebViewController.setUrl( urlEndpoint:recipe.href )
            
        }
    }
    
    
}

//MARK: UICollectionViewDataSource
extension RecipeSearchViewController: UICollectionViewDataSource
{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return RecipeModelSingleton.instance.getRecipeCount()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RecipeCollectionViewCell", for: indexPath) as! RecipeCollectionViewCell

        //get recipe for this row
        let recipe = RecipeModelSingleton.instance.getRecipe(index:indexPath.row)
        
        //load up the custom cell
        cell.recipeTitleLabel.text          = recipe?.title
        cell.recipeIngredientsLabel.text    = recipe?.ingredients
        cell.href = recipe?.href
        //hide the button if no link
        if (recipe?.href.count == 0 ){
            cell.shopRecipeButton.alpha = 0
        }
        
        //load the image from the cache
        cell.recipeImageView.image = cachedCellThumbnailImages[indexPath.row]
        //set the buttons tag to the index
        cell.shopRecipeButton.tag = indexPath.row
            
        return cell
    }
    
}
