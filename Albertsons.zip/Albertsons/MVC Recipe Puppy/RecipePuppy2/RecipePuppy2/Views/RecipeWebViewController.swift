//
//  RecipeWebViewController.swift
//  RecipePuppy2
//
//  Created by Scott Stahurski on 8/30/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import UIKit
import WebKit

class RecipeWebViewController: UIViewController {

    var recipeUrl:String!
    
    @IBOutlet var recipeWebView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        let url = URL(string: recipeUrl)!
        recipeWebView.load(URLRequest(url: url))
        recipeWebView.allowsBackForwardNavigationGestures = true
    }
    
    func setUrl( urlEndpoint:String ){
        self.recipeUrl = urlEndpoint
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
