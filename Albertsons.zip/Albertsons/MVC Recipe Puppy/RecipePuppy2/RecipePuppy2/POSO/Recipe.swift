//
//  Recipe.swift
//  RecipePuppy2
//
//  Created by Scott Stahurski on 8/30/20.
//  Copyright © 2020 Scott Stahurski. All rights reserved.
//

import UIKit

struct Recipe: Decodable
{
    var title:String
    var href:String
    var ingredients:String
    var thumbnail:String
    
    init( recipeTitle: String, recipeHref: String, recipeIngredients: String, recipeThumbnail:String) {
        self.title = recipeTitle
        self.href = recipeHref
        self.ingredients = recipeIngredients
        self.thumbnail = recipeThumbnail
    }
    
}

struct RecipePage : Decodable
{
    var title:String
    var version:Float
    var href:String
    var results:[Recipe]
    
}
